"""Vibe-Trading core package."""

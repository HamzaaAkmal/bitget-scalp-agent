"""Core module: Runner + RunStateStore."""
